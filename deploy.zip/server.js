const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = process.env.PORT || 8081;

const server = http.createServer((req, res) => {
  console.log(`Received request for: ${req.url}`);
  
  // API routes
  if (req.url === '/api/telemetry/global') {
    res.writeHead(200, {'Content-Type': 'application/json'});
    
    // Return a mock response that includes multiple fields in case any of them is expected
    const mockResponse = {
      telemetryData: [
        { region: "North America", countryId: "US", name: "United States", status: "green" },
        { region: "Europe", countryId: "UK", name: "United Kingdom", status: "yellow" },
        { region: "Europe", countryId: "DE", name: "Germany", status: "green" },
        { region: "Europe", countryId: "FR", name: "France", status: "green" }
      ],
      // Also include the same data in different properties to cover all bases
      data: [
        { region: "North America", countryId: "US", name: "United States", status: "green" },
        { region: "Europe", countryId: "UK", name: "United Kingdom", status: "yellow" },
        { region: "Europe", countryId: "DE", name: "Germany", status: "green" },
        { region: "Europe", countryId: "FR", name: "France", status: "green" }
      ],
      countries: [
        { region: "North America", countryId: "US", name: "United States", status: "green" },
        { region: "Europe", countryId: "UK", name: "United Kingdom", status: "yellow" },
        { region: "Europe", countryId: "DE", name: "Germany", status: "green" },
        { region: "Europe", countryId: "FR", name: "France", status: "green" }
      ]
    };
    
    console.log('Sending global telemetry data:', JSON.stringify(mockResponse));
    res.end(JSON.stringify(mockResponse));
    return;
  }
  
  // Rest of the code stays the same...
