const http = require('http');
const PORT = process.env.PORT || 8081;

// Create a basic server
const server = http.createServer((req, res) => {
  console.log(`Request received: ${req.url}`);
  
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  // Handle API routes
  if (req.url === '/api/telemetry/global') {
    res.writeHead(200, {'Content-Type': 'application/json'});
    const data = {
      telemetryData: [
        { region: "North America", countryId: "US", name: "United States", status: "green" },
        { region: "Europe", countryId: "UK", name: "United Kingdom", status: "yellow" },
        { region: "Europe", countryId: "DE", name: "Germany", status: "green" },
        { region: "Europe", countryId: "FR", name: "France", status: "green" }
      ]
    };
    res.end(JSON.stringify(data));
    return;
  }
  
  if (req.url.startsWith('/api/telemetry/country/')) {
    const countryId = req.url.split('/').pop();
    res.writeHead(200, {'Content-Type': 'application/json'});
    const data = {
      countryId,
      name: countryId === "US" ? "United States" : countryId,
      status: "green",
      lastUpdate: new Date().toISOString()
    };
    res.end(JSON.stringify(data));
    return;
  }
  
  if (req.url === '/api/history') {
    res.writeHead(200, {'Content-Type': 'application/json'});
    const data = {
      history: [
        { date: "2025-03-01", status: "green" },
        { date: "2025-03-02", status: "yellow" },
        { date: "2025-03-03", status: "green" }
      ]
    };
    res.end(JSON.stringify(data));
    return;
  }
  
  // Default response for all other routes
  res.writeHead(200, {'Content-Type': 'text/html'});
  res.end(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>Telephony Monitor</title>
      </head>
      <body>
        <h1>Telephony Monitoring API</h1>
        <p>Server is running. Available endpoints:</p>
        <ul>
          <li><a href="/api/telemetry/global">/api/telemetry/global</a></li>
          <li><a href="/api/telemetry/country/US">/api/telemetry/country/US</a></li>
          <li><a href="/api/history">/api/history</a></li>
        </ul>
        <p>Current time: ${new Date().toISOString()}</p>
      </body>
    </html>
  `);
});

// Start the server
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
