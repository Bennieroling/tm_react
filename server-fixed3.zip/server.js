const express = require("express");
const cors = require("cors");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3001;

// Configure CORS
app.use(cors({
  origin: "https://wetesttmstorv2.z6.web.core.windows.net",
  credentials: true
}));

// Existing server code
require("./src/index");

// Serve static files (if you have any)
app.use(express.static(path.join(__dirname, "public")));

// Add a simple route for the root path
app.get("/", (req, res) => {
  res.send("Telephony Monitor API Server is running");
});

// Start the server if this file is executed directly
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}
