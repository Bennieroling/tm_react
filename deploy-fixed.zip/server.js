const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = process.env.PORT || 8081;

// Utility function to determine content type
const getContentType = (filePath) => {
  const extname = path.extname(filePath);
  switch (extname) {
    case '.html': return 'text/html';
    case '.js': return 'text/javascript';
    case '.css': return 'text/css';
    case '.json': return 'application/json';
    case '.png': return 'image/png';
    case '.jpg': return 'image/jpeg';
    case '.svg': return 'image/svg+xml';
    case '.ico': return 'image/x-icon';
    default: return 'text/plain';
  }
};

// Create a server
const server = http.createServer((req, res) => {
  console.log(`Request received: ${req.url}`);
  
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  // Handle API routes
  if (req.url === '/api/telemetry/global') {
    res.writeHead(200, {'Content-Type': 'application/json'});
    // Return just the array, not an object containing the array
    const data = [
      { region: "North America", countryId: "US", name: "United States", status: "green" },
      { region: "Europe", countryId: "UK", name: "United Kingdom", status: "yellow" },
      { region: "Europe", countryId: "DE", name: "Germany", status: "green" },
      { region: "Europe", countryId: "FR", name: "France", status: "green" }
    ];
    res.end(JSON.stringify(data));
    return;
  }
  
  // Other API endpoints remain the same...
